# Multi-path stories application

The application consist of a simple table design with little CSS-styling where the user can input stories. 
The application starts with a story sentence: "Once upon a time there was a girl who wanted to fly".
It is then up to the user to create the story by writing up to four different sentences for every sentence that the user just created.
Once story can therefore have multiple paths and the story can be different depending on the users choices.  


## Implementation
The application is implemented using:
* Flask framework
* Python
* CSS

